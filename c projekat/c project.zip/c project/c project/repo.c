#include <mongoc/mongoc.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    mongoc_client_t* client;
    FILE* logger;
} Repository;

Repository* New(FILE* logger) {

    //hardcoded for now
    const char* dburi = "mongodb://localhost:27017/";


    if (dburi == NULL) {
        fprintf(logger, "Error: MONGO_DB_URI environment variable is not set\n");
        return NULL;
    }

    // Initialize MongoDB C driver
    mongoc_init();

    // Create MongoDB client
    mongoc_client_t* client = mongoc_client_new(dburi);
    if (!client) {
        fprintf(logger, "Error: Failed to create MongoDB client\n");
        mongoc_cleanup();
        return NULL;
    }

    // Test connection (MongoDB C driver doesn't use an explicit connect step)
    bson_error_t error;
    if (!mongoc_client_get_server_status(client, NULL, NULL, &error)) {
        fprintf(logger, "Error: Failed to connect to MongoDB: %s\n", error.message);
        mongoc_client_destroy(client);
        mongoc_cleanup();
        return NULL;
    }

    // Allocate memory for the Repository struct
    Repository* repo = (Repository*)malloc(sizeof(Repository));
    if (repo == NULL) {
        fprintf(logger, "Error: Failed to allocate memory for repository\n");
        mongoc_client_destroy(client);
        mongoc_cleanup();
        return NULL;
    }

    // Set up the Repository struct fields
    repo->client = client;
    repo->logger = logger;

    return repo;
}

// Cleanup function to release resources
void Cleanup(Repository* repo) {
    if (repo) {
        mongoc_client_destroy(repo->client);
        free(repo);
    }
    mongoc_cleanup();
}

int adduser() {

    FILE* log = fopen("log.txt", "w");
    if (log == NULL) {
        printf("Error opening file!\n");
    }

    Repository *repo = New(log); 
    

}