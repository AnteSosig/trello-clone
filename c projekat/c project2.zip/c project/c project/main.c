#include <microhttpd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <cjson/cJSON.h>
#include "model.h"
#include "repo.h"

#define PORT 8080

// Function to handle requests and send responses
int answer_to_connection(void* cls, struct MHD_Connection* connection,
    const char* url, const char* method, const char* version,
    const char* upload_data, size_t* upload_data_size, void** con_cls) {

    // Define a simple "route" for "/user"
    if (strcmp(url, "/newuser") == 0 && strcmp(method, "POST") == 0) {
        static int upload_in_progress = 1;

        if (*upload_data_size > 0 && upload_in_progress) {
            // Allocate memory to store the incoming JSON data
            char* json_data = (char*)malloc(*upload_data_size + 1);
            strncpy(json_data, upload_data, *upload_data_size);
            json_data[*upload_data_size] = '\0';  // Null-terminate the string

            // Parse the JSON using cJSON
            cJSON* json = cJSON_Parse(json_data);
            if (json == NULL) {
                const char* error_response = "Invalid JSON format";
                struct MHD_Response* response = MHD_create_response_from_buffer(strlen(error_response),
                    (void*)error_response,
                    MHD_RESPMEM_PERSISTENT);
                int ret = MHD_queue_response(connection, MHD_HTTP_BAD_REQUEST, response);
                MHD_destroy_response(response);
                free(json_data);
                return ret;
            }

        /*    cJSON* first_name = cJSON_GetObjectItem(json, "first_name");
            cJSON* last_name = cJSON_GetObjectItem(json, "last_name");
            cJSON* email = cJSON_GetObjectItem(json, "email");
            cJSON* password = cJSON_GetObjectItem(json, "password");

            if (cJSON_IsString(first_name) && first_name->valuestring != NULL &&
                cJSON_IsString(last_name) && last_name->valuestring != NULL &&
                cJSON_IsString(email) && email->valuestring != NULL &&
                cJSON_IsString(password) && password->valuestring != NULL) { */

            User user;
            if (parse_user_from_json(json, &user) == 0) {
                printf("Name: %s\n", user.first_name);
                printf("Surname: %s\n", user.last_name);
                printf("Email: %s\n", user.email);
                printf("Password: %s\n", user.password);

                User* user = &user;
                if (adduser(user) == 0) {

                    // Build a response
                    const char* response_str = "User data received";
                    struct MHD_Response* response = MHD_create_response_from_buffer(strlen(response_str),
                        (void*)response_str,
                        MHD_RESPMEM_PERSISTENT);
                    MHD_add_response_header(response, "Access-Control-Allow-Origin", "*");
                    int ret = MHD_queue_response(connection, MHD_HTTP_OK, response);
                    MHD_destroy_response(response);

                    // Clean up
                    cJSON_Delete(json);
                    free(json_data);
                    return ret;
                }
                else {
                    const char* error_response = "User not added";
                    struct MHD_Response* response = MHD_create_response_from_buffer(strlen(error_response),
                        (void*)error_response,
                        MHD_RESPMEM_PERSISTENT);
                    int ret = MHD_queue_response(connection, MHD_HTTP_BAD_REQUEST, response);
                    MHD_destroy_response(response);

                    // Clean up
                    cJSON_Delete(json);
                    free(json_data);
                    return ret;
                }
            }
            else {
                const char* error_response = "Missing or invalid fields";
                struct MHD_Response* response = MHD_create_response_from_buffer(strlen(error_response),
                    (void*)error_response,
                    MHD_RESPMEM_PERSISTENT);
                int ret = MHD_queue_response(connection, MHD_HTTP_BAD_REQUEST, response);
                MHD_destroy_response(response);

                // Clean up
                cJSON_Delete(json);
                free(json_data);
                return ret;
            }
        }
    }

    if (strcmp(url, "/user") == 0) {
        const char* response_str = "User route";
        struct MHD_Response* response = MHD_create_response_from_buffer(strlen(response_str),
            (void*)response_str,
            MHD_RESPMEM_PERSISTENT);
        MHD_add_response_header(response, "Access-Control-Allow-Origin", "*"); // CORS header
        int ret = MHD_queue_response(connection, MHD_HTTP_OK, response);
        MHD_destroy_response(response);
        return ret;
    }

    // Default 404 not found response
    const char* not_found = "404 - Not Found";
    struct MHD_Response* response = MHD_create_response_from_buffer(strlen(not_found),
        (void*)not_found,
        MHD_RESPMEM_PERSISTENT);
    int ret = MHD_queue_response(connection, MHD_HTTP_NOT_FOUND, response);
    MHD_destroy_response(response);
    return ret;
}

int main() {
    struct MHD_Daemon* daemon;

    // Set the PORT from environment variable, fallback to default PORT 8080
    char* port_env = getenv("PORT");
    int port = port_env ? atoi(port_env) : PORT;

    // Start the HTTP server
    daemon = MHD_start_daemon(MHD_USE_SELECT_INTERNALLY, port, NULL, NULL,
        &answer_to_connection, NULL, MHD_OPTION_END);

    if (NULL == daemon) {
        printf("Failed to start server\n");
        return 1;
    }

    printf("Server running on port %d\n", port);

    // Run indefinitely (could also add logic to handle graceful shutdowns)
    getchar();

    MHD_stop_daemon(daemon);
    return 0;
}
