#ifndef REPO_H
#define REPO_H

#include "model.h"

int adduser(User* user);

#endif